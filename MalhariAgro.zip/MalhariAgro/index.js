function toggleMenu() {
    var navUl = document.querySelector('nav ul');
    navUl.classList.toggle('show');
}
$(document).ready(function(){
    $(".owl-carousel").owlCarousel({
        items: 6,
        loop: true,
        margin: 10,
        autoplay: true,
        autoplayTimeout: 2000, // Set the time interval for auto sliding in milliseconds
        autoplayHoverPause: true,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:3
            },
            1000:{
                items:6
            }
        }
    });
})
